#!/usr/bin/env node
const puppeteer = require('puppeteer');
const { TimeoutError } = require('puppeteer/Errors');
const 表單資訊 = require('./表單資訊.js');

const autoSign = async (報名場次) => {
    const browser = await puppeteer.launch({
        // executablePath: 表單資訊.Google路徑,
        args: ['--no-sandbox'],
        headless: false,
        defaultViewport: {
            width: 800,
            height: 600,
        }
    });

    const page = await browser.newPage();
    await page.goto(表單資訊.報名網址);

    await page.waitFor('.freebirdThemedRadio');
    const radioButtons = await page.$$('.freebirdThemedRadio');

    // 場次:
    if (報名場次 === 1) radioButtons[0].click();
    if (報名場次 === 2) radioButtons[1].click();

    // ID
    await page.waitFor('input[aria-label="遊戲王ID"]');
    await page.type('input[aria-label="遊戲王ID"]', 表單資訊.ID);

    // 居住地
    radioButtons[2].click();

    // 年齡
    await page.waitFor('input[aria-label="年齡"]');
    await page.type('input[aria-label="年齡"]', String(表單資訊.年齡));

    // 真實姓名
    await page.waitFor('input[aria-label="真實姓名"]');
    await page.type('input[aria-label="真實姓名"]', String(表單資訊.姓名));

    // 生日
    await page.waitFor('input[type="date"]');
    await page.type('input[type="date"]', String(表單資訊.生日));

    // 身分證字號
    await page.waitFor('input[aria-label="身分證字號"]');
    await page.type('input[aria-label="身分證字號"]', String(表單資訊.身分證字號));

    // 卡套領取店家
    await page.tap('[role="listbox"]');
    await page.waitFor(200);
    const options = await page.$$(`[data-value="${表單資訊.卡套領取店家}"]`);
    options[options.length - 1].click();

    // 確定送出
    await page.waitFor(300);
    const button = await page.$(`[role="button"]`);
    button.click();

    while (await page.$(`[role="button"]`) !== null) {
        await page.waitFor(300);
        const button = await page.$(`[role="button"]`);
        button.click();

        console.log("表單未送出，嘗試重新送出表單");
    }

    console.log('場次' + 報名場次 + ' 報名完成！');
};

(async () => {
    autoSign(1);
    autoSign(2);
})();